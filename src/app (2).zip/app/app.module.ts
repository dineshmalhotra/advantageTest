import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {Component1} from './component1/component1'
import {Component1Child} from './component1/component1.child'
@NgModule({
  declarations: [
    AppComponent,
    Component1,
    Component1Child
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
