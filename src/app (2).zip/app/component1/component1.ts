import {Component,OnInit,OnDestroy} from '@angular/core'

@Component({
    selector:'component-1',
    templateUrl:'./component1.html'
})

export class Component1 implements OnInit,OnDestroy{
    test1:number;
    arr1:string[];
    isDetail:boolean = false;
    data1:string;
    constructor(){

    }
    ngOnInit(){
        this.test1 = 5;
        this.arr1 = ['a','b','c','d'];
        this.data1 = "we will give test child data"
    }
    ngOnDestroy(){

    }

    fn1(){
        let a:string  = "";
        if(a != ""){
            this.isDetail = true
        } else {
            this.isDetail = false;
        }
    }
    fn2(val:number){
        console.log(val)
    }
    parentOut1(ev:string){
        alert(ev)
    }
}